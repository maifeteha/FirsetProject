package test;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;
import page.LoginPage;
import page.SearshProductPage;

public class SearchProductTest extends HomeTest{
  @Test
    public void shearchToApp(Object Category)
  {
    SearshProductPage searshProductPage = new SearshProductPage(driver);
    LoginPage loginPage = new LoginPage(driver);
    searshProductPage = searshProductPage.shearchToAppWithValidCredentials("top blue");
   // Assert.assertEquals(searshProductPage.getTextOfElement(By.className("class=\"panel-group category-products\");)
  }
  }



