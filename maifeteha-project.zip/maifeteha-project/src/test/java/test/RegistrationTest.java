package test;

import org.testng.Assert;
import org.testng.annotations.Test;
import page.NavigationBarPage;
import page.RegistratioPage;
import page.SuccessfulRegistrationPage;

public class RegistrationTest extends HomeTest{
    @Test
    public void loginToApp(){
        NavigationBarPage navigationBarPage = new NavigationBarPage(driver);
        RegistratioPage registratioPage = new RegistratioPage(driver);
        SuccessfulRegistrationPage successfulRegistrationPage = new SuccessfulRegistrationPage(driver);
        registratioPage.registerNewUser("mai","feteha","maifeteha2011@gmail.com","123456","cairo","elharam","giza","cairo","giza","1234566","01092738167");
        Assert.assertEquals(successfulRegistrationPage.getSuccessfulRegistrationMsg(),"Automation Exercise Full-Fledged practice website for Automation Engineers");
    }

}
