package test;

import org.testng.Assert;
import org.testng.annotations.Test;
import page.HomePage;
import page.LoginPage;
import page.NavigationBarPage;

public class LoginTest extends HomeTest {
    @Test
            public void loginToApp()

    {
        NavigationBarPage navigationBarPage = new NavigationBarPage(driver);
        LoginPage loginPage = new LoginPage(driver);
        LoginPage loginPage1= new LoginPage(driver);
        HomePage homePage = loginPage.loginToAppWithValidCredentials("maifeteha2011@gmail.com",
                "1234567");
        Assert.assertEquals(homePage.getWelcomeMsg(),"Website for automation practice");
    }

}
