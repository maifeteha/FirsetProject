package test;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class AddToCartTest extends HomeTest {
    @BeforeMethod
    public void loginToAppAsPrecondition() {

    }

    @Test
    public void testAddToCart() {

    }


}
